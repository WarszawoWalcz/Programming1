package nl.ru.ai.exercise4;

import java.util.ArrayList;

public class Exercise4 {
  public static int nrOfFails = 0;
  public static int nrOfPrunes = 0;


  public static void main(String[] args) {
    ArrayList<Integer> solution = new ArrayList<Integer>();

    int[] money0 = {};
    int target0 = 0;
    System.out.println("case 1:");
    System.out.println("number of solutions: " + solutions(money0, 0, target0, solution));
    System.out.println("number of failures: " + nrOfFails + "\n");

    int[] money1 = {2, 2, 2, 5, 10, 10, 20};
    int target1 = 1;
    solution.clear();
    System.out.println("case 2:");
    System.out.println("number of solutions: " + solutions(money1, 0, target1, solution));
    System.out.println("number of failures: " + nrOfFails + "\n");

    int[] money2 = {20, 10, 10, 5, 2, 2, 2};
    int target2 = 42;
    solution.clear();
    System.out.println("case 3:");
    System.out.println("number of solutions: " + solutions(money2, 0, target2, solution));
    System.out.println("number of failures: " + nrOfFails + "\n");

    int[] money3 = {20, 50, 1000, 1000, 2000};
    int target3 = 2021;
    solution.clear();
    System.out.println("case 4:");
    System.out.println("number of solutions: " + solutions(money3, 0, target3, solution));
    System.out.println("number of failures: " + nrOfFails);
  }

  /**
   * Returns the number of ways of creating specified target value as a sum of money starting with c
   *
   * @param money
   * @param c
   * @param target
   * @return number of ways
   */
  private static int solutions(int[] money, int c, int target, ArrayList<Integer> s) {
    assert money != null : "array should be initialized";
    assert c >= 0 && c <= money.length;

    if (target == 0) {
      showSolution(s);
      return 1;
    } else if (target < 0) {
      nrOfFails++;
      return 0;
    } else if (c >= money.length) {
      nrOfFails++;
      return 0;
    } else if (sum(c) < target) {

    } else if () {

    } else {
      s.add(money[c]);
      int with = solutions(money, c + 1, target - money[c], s);
      s.remove(s.size() - 1);
      int without = solutions(money, c + 1, target, s);
      return with + without;
    }
  }

  private static void showSolution(ArrayList<Integer> solution) {
    System.out.println(solution);
  }

  private static int sum(int c) {
    assert n >= 0 : "n should be a positive number";
    if (n == 0) {
      return 0;
    } else {
      return n + sum(n - 1);
    }

  }
}
