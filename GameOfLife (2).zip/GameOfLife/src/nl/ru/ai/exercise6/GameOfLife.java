package nl.ru.ai.exercise6;

import nl.ru.ai.gameoflife.Cell;

import java.io.*;
import java.lang.management.BufferPoolMXBean;

import static nl.ru.ai.gameoflife.Universe.*;

public class GameOfLife
{

  public static void main(String[] args)
  {
      showUniverse(readUniverseFile("pulsar.txt"));
      //nextGeneration(readUniverseFile("pulsar.txt"));

  }

  static Cell[][] readUniverseFile(String fileName)
  {
      fileCheck(fileName);
      Cell[][] universe = new Cell[40][60];
      try{
          BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));
          String line;
          for(int i = 0; i <= 39; i++){
              line = reader.readLine();
              for(int j = 0; j<=59; j++){
                  if(line.charAt(j) == '.'){
                      universe[i][j] = Cell.DEAD;
                  } else if (line.charAt(j) == '*'){
                      universe[i][j] = Cell.LIVE;
                  } else {
                      throw new IllegalArgumentException("Invalid character");
                  }
              }
          }
          reader.close();
      } catch (FileNotFoundException e) {
          throw new IllegalArgumentException("file not found");
      } catch (IOException e) {
          e.printStackTrace();
      }

      return universe;
  }

    private static void fileCheck(String fileName) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));

            int num_of_lines = 0;
            String line;
            while((line = reader.readLine()) != null){
                if(line.length() != 60){
                    throw new IllegalArgumentException("Invalid number of columns");
                }
                for (int i = 0; i != 59 ; i++) {
                    if(line.charAt(0) == '*' || line.charAt(line.length()-1) == '*'){
                        throw new IllegalArgumentException("There shouldn't be live cells at the boarders");
                    }
                    if((num_of_lines == 0 || num_of_lines == 39) && line.charAt(i) == '*'){
                        throw new IllegalArgumentException("There shouldn't be live cells at the boarders");
                    }
                }
                num_of_lines++;
            }
            reader.close();
            if (num_of_lines != 40){
                throw new IllegalArgumentException("Invalid number of rows");
            }
        } catch (FileNotFoundException e) {
            throw new IllegalArgumentException("file not found");
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

  private static void showUniverse(Cell[][] universe)
  {
    for(int i=0; i<40; i++){
        for(int j=0; j<60; j++){
            updateScreen(i, j, universe[i][j]);
        }
    }
  }

  private static Cell[][] nextGeneration(Cell[][] universe)
  {
      for(int i=0; i<40; i++){
          for(int j=0; j<60; j++){
              if(universe[i][j] == Cell.LIVE){
                  for (int k = 1; k < 9; k++) {

                  }
                  check_surrounding(universe[i][j]);
              }
          }
      }
      return universe;
  }

    private static void check_surrounding(Cell[][] universe) {
//        if(universe[0][0] == Cell.LIVE){
//            if(universe[i][j] == ){
//
//            }
//        }
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (universe[][] ){

                }
            }
        }
    }

}
